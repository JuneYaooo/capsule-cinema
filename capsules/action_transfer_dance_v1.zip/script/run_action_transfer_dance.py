#!/usr/bin/env python3
"""action_transfer_dance_v1 胶囊的本地编排脚本。

入参 JSON (从 --params 读, 或 stdin):
    character_prompt       : str   角色描述(中文优先, 例: "年轻武术家, 黑色练功服")
                                   reference_image 给了时可空 (让模型靠图片本身判断角色)
    reference_image        : str   本地角色参考图路径 (可选, 例: 一张人脸/胸像/角色海报)
                                   给了之后会走图生图, 自动扩成 9:16 全身正面照,
                                   并保留参考图的脸型/表情/肤色/服装配色不动
    reference_video        : str   本地参考动作视频路径 (必填)
    single_or_multi_person : str   "single" (默认) / "multi"
    action_style           : str   补充节奏/动作风格说明 (可空)
    aspect_ratio           : str   "9:16" / "16:9" / "1:1", 默认 9:16
    target_duration        : int   裁剪上限(秒), 默认 12, 上限 20
    add_bgm                : bool  是否叠 BGM, 默认 True
    bgm_query              : str   BGM 关键词 / Suno tags (例: "epic anime battle drums" 或 "中文古风,笛,情绪递进")
    bgm_provider           : str   "auto" (默认, 先在线搜, 没找到就 Suno 兜底) / "online" / "suno"
    image_engine           : str   首选引擎; 默认 Seedream5ImageGeneratorTool
                                   带 reference_image 时, GptImage2 会被排除 (不支持 ref)

流程:
    1. 准备 run dir
    2. 校验 + (必要时) 裁剪参考视频
    3. 生成角色全身竖屏图
       - 无 reference_image: 纯文生图 (character_prompt 必填)
       - 有 reference_image: 图生图, 自动扩成 9:16 全身, 保留脸/表情/服装
    4. 调 RunningHub 动作迁移 (ActionImitateTool 或 WanMultiPersonActionImitateTool)
    5. (可选) 叠 BGM
    6. 落地 release/ + artifact_manifest + QA
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LIB = ROOT / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


DEFAULT_REFERENCE_VIDEO = ROOT / "my_capsule_kit" / "mv_demo" / "pk_demo_1.mp4"


def ensure_run_dirs(run_dir: Path) -> dict[str, Path]:
    dirs = {
        "inputs": run_dir / "inputs",
        "work": run_dir / "work",
        "frames": run_dir / "work" / "frames",
        "videos": run_dir / "work" / "videos",
        "audio": run_dir / "work" / "audio",
        "qa": run_dir / "qa",
        "release": run_dir / "release",
        "logs": run_dir / "logs",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def run_tool(tool_name: str, params: dict[str, Any], *, stream: bool = True) -> dict[str, Any] | str:
    """跑 scripts/run_tool.py 调一个底层工具。

    stream=True (默认): 子进程的 stdout/stderr 实时打到当前进程的屏幕上,
    用户能看到 Seedream5/RunningHub 的进度行 (上传/排队/下载...), 不会以为卡住了。
    最后会把同一份输出 capture 一份用来解析返回值。
    """
    import io

    cmd = [
        sys.executable,
        "-u",  # 关掉 Python 输出缓存, 让子进程的 print 立刻可见
        str(SCRIPTS / "run_tool.py"),
        "--tool",
        tool_name,
        "--params",
        json.dumps(params, ensure_ascii=False),
    ]

    if not stream:
        result = subprocess.run(cmd, cwd=str(ROOT), text=True, capture_output=True)
        rc, stdout, stderr = result.returncode, result.stdout, result.stderr
    else:
        # 用 Popen 边读边打印; 同时收集到 buffer 用于返回值解析
        buf = io.StringIO()
        print(f"\n┌─ [run_tool] {tool_name} ─────────────────────────────")
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,  # 行缓冲
        )
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                sys.stdout.write(f"│ {line}")
                sys.stdout.flush()
                buf.write(line)
        finally:
            rc = proc.wait()
        print(f"└─ [run_tool] {tool_name} exit={rc} ─────────────────────\n")
        stdout = buf.getvalue()
        stderr = ""

    if rc != 0:
        raise RuntimeError(
            f"{tool_name} failed: {stderr[-1500:] or stdout[-1500:]}"
        )
    text = stdout.strip()
    if "{" in text:
        try:
            return json.loads(text[text.find("{") :])
        except json.JSONDecodeError:
            return text
    return text


def ffprobe_duration(video_path: Path) -> float:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=nw=1:nk=1",
            str(video_path),
        ],
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe failed on {video_path}: {result.stderr.strip()}")
    return float(result.stdout.strip() or 0.0)


def trim_reference_video(src: Path, dst: Path, max_seconds: float) -> Path:
    duration = ffprobe_duration(src)
    if duration <= max_seconds + 0.5:
        shutil.copy2(src, dst)
        return dst
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-ss",
            "0",
            "-i",
            str(src),
            "-t",
            f"{max_seconds}",
            "-c",
            "copy",
            str(dst),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return dst


def extract_first_frame(video_path: Path, dst: Path, *, at_seconds: float = 0.5) -> Path:
    """抽 video 的某一帧做姿态参考图。默认抽 0.5s 处, 比 frame 0 稳定 (避开开机黑帧)。"""
    dst.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-ss",
            f"{at_seconds}",
            "-i",
            str(video_path),
            "-frames:v",
            "1",
            "-q:v",
            "2",
            str(dst),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if not dst.is_file() or dst.stat().st_size < 1024:
        raise RuntimeError(f"抽参考视频首帧失败: {video_path} -> {dst}")
    return dst


def detect_video_aspect_ratio(video_path: Path) -> str:
    """检测视频 width/height, 映射到 '9:16' / '16:9' / '1:1' 的最近档位。"""
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "stream=width,height",
            "-select_streams",
            "v:0",
            "-of",
            "csv=p=0",
            str(video_path),
        ],
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        return "9:16"
    raw = result.stdout.strip().split(",")
    if len(raw) < 2:
        return "9:16"
    try:
        w, h = int(raw[0]), int(raw[1])
    except ValueError:
        return "9:16"
    if h == 0:
        return "9:16"
    ratio = w / h
    # 选最近的标准档位
    candidates = {
        "9:16": 9 / 16,
        "16:9": 16 / 9,
        "1:1": 1.0,
    }
    best = min(candidates.items(), key=lambda kv: abs(kv[1] - ratio))
    return best[0]


def has_audio_stream(video_path: Path) -> bool:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "stream=index",
            "-of",
            "csv=p=0",
            str(video_path),
        ],
        text=True,
        capture_output=True,
    )
    return result.returncode == 0 and bool(result.stdout.strip())


def dimensions_for_aspect_ratio(ratio: str) -> tuple[int, int]:
    if ratio == "16:9":
        return 1280, 720
    if ratio == "1:1":
        return 1024, 1024
    return 720, 1280


def build_character_prompt(raw: str, action_style: str) -> str:
    extras = action_style.strip()
    base = raw.strip() or "一位年轻演员, 竖屏全身正面照"
    pieces = [
        base,
        "全身入镜, 头脚不裁切, 站姿松弛自然, 身体可清晰看到双手双脚",
        "纯色或弱纹理背景, 不要复杂道具不要多个重叠人物",
        "服装颜色对比明显, 不要长裙长袍盖住腿脚",
        "电影级硬光打底, 9:16 竖屏构图",
    ]
    if extras:
        pieces.append(f"动作风格参照: {extras}")
    pieces.append("不要任何文字水印 Logo 或边框")
    return ", ".join(pieces)


def build_dual_reference_prompt(raw: str, action_style: str) -> str:
    """**双图模式**: 同时给"身份参考图"和"姿态参考图(视频首帧)"。

    输出图必须:
      - 身份 / 物种 / 外观 / 表情 / 服装 完全跟 IDENTITY 图一致
      - 姿态 / 取景 / 比例 / 在画面中的位置 跟 POSE 图(视频首帧)对齐
    这一步是让 RunningHub 动作迁移的骨架有的可对(尤其是非人物种, 需要按人形姿势扮演)。
    """
    extras = action_style.strip()
    user_hint = raw.strip()
    pieces = []
    if user_hint:
        pieces.append(
            f"主体身份 (以此为准, 不要改): {user_hint}. "
            "无论看起来像什么, 都按这里写的物种/角色去识别和画 "
            "(例: 无毛猫=真无毛猫, 不要画成穿同色衣服的人)"
        )
    pieces.extend([
        # 解释两张参考图的角色
        "本次提供了两张参考图: (A) IDENTITY = 角色身份参考图(脸/物种/毛色/表情/服装), (B) POSE = 姿态参考图(取景/构图/比例/缩放/在画面中的位置/主体的肢体姿势)",
        "★ 必须严格保留 IDENTITY 图的所有视觉特征: 物种 / 脸型 / 肤色或毛色 / 五官比例 / 眼神 / 表情 / 发型或耳朵形状 / 服装颜色和图案",
        "★ 必须严格照抄 POSE 图的: 取景大小 / 主体在画面中的位置和占比 / 主体的整体姿势(站/坐/蹲/跑/跳/出拳...) / 镜头角度(正面/侧面/俯仰)",
        "**如果 IDENTITY 是动物 (猫/狗/兔...), 而 POSE 是真人姿势 → 让动物按人形姿势扮演: 用后腿站立, 前肢模拟人的手臂动作, 头身比例参考 POSE 的人体比例, 这样后续动作迁移引擎才能把人体骨架对到这只动物上**",
        "**如果 IDENTITY 是已知 IP, 按 IP 的造型补全身体, 但姿势/构图严格按 POSE**",
        "如果 IDENTITY 和 POSE 都是真人 (或人形), 把 IDENTITY 的人换成 POSE 的姿势即可",
        # 输出框
        "输出图与 POSE 图同样的画面比例和取景, 主体在画面中的位置/缩放与 POSE 一致, 不要重新构图",
        "保留 POSE 图的背景色调和氛围 (如果背景太复杂可简化, 但不要换成纯白)",
    ])
    if extras:
        pieces.append(f"动作风格补充 (仅作肢体表达参考, 不要改物种或视觉风格): {extras}")
    pieces.append("不要任何文字水印 Logo 或边框, 不要在画面中添加文字")
    return "; ".join(pieces)


def build_reference_character_prompt(raw: str, action_style: str) -> str:
    """带 reference_image 的图生图提示词:**优先保留参考图物种/身份/表情/服装/风格**, 仅扩展到全身。

    关键修正 (vs v5 第一版): 不能预设主体是"人"。参考图可能是猫/狗/手办/3D角色,
    强加"双脚分开/双手下垂"会让模型把无毛猫错画成"穿粉衣的人"。
    character_prompt 提到的物种 (无毛猫/比鲁斯/...) 必须**强力主导**身份识别, 放最前面。
    """
    extras = action_style.strip()
    user_hint = raw.strip()
    pieces = []

    # 第一条: 用户给的身份提示, 优先级最高 (如果有)
    if user_hint:
        pieces.append(
            f"主体身份 (以此为准, 不要改): {user_hint}. "
            "无论参考图看起来像什么, 都按这里写的物种/角色去识别和画 "
            "(例: 无毛猫=真无毛猫, 不是穿粉衣的人; 比鲁斯=破坏神, 不是普通猫人)"
        )

    pieces.extend([
        # 物种 + 风格 自动跟随参考图, 严禁跨物种
        "AUTO-DETECT 参考图的物种 (人/猫/狗/鸟/兽/虚构生物/3D 角色) 和视觉风格 (真人照片/真实动物/动漫/CG/手办), "
        "输出图必须与参考图同一物种、同一风格, 严禁跨物种或跨风格转换",
        "参考图是真实动物 → 输出真实动物的全身, 保留毛色/皮肤纹理/瞳孔/耳朵形状/胡须 等动物特征, "
        "绝对不要画成穿同色衣服的人, 也不要拟人化",
        "参考图是真人 → 输出真人级照片质感的全身, 不要二次元化",
        "参考图是动漫角色 → 输出原画风的动漫全身",
        "参考图是 3D CG / 手办 → 保持 3D 渲染或手办质感",
        # 身份保留 (与物种无关)
        "严格保留参考图主体的身份/脸型/肤色或毛色/五官比例/眼神/表情/发型或耳朵形状/服装颜色和图案/标志性物件",
        "如果参考图是已知动漫/电影/游戏 IP, 按该 IP 的标准全身造型自动补全身体, 不改造型",
        "如果是普通真人或普通动物, 按参考图的容貌/毛色/服装风格自然延展为全身, 不改容貌",
        # 镜头框架 (物种自适应, 不假设两条腿)
        "把镜头从面部特写拉远, 输出 9:16 竖屏全身入镜照, 头脚/头尾不裁切, 主体在画面中央",
        "如果是四足动物, 用自然的站姿或坐姿 (跟参考图一致最好), 不要强行扳成两足人形姿态",
        "如果是人或两足角色, 自然站姿即可",
        # 背景
        "保留参考图原有的背景色调和氛围, 不要随意换成纯白; 但避免复杂的多人/复杂道具",
    ])

    if extras:
        pieces.append(f"动作风格参照 (仅作姿态参考, 不要改物种或视觉风格): {extras}")
    pieces.append("不要任何文字水印 Logo 或边框, 不要在画面中添加文字")
    return "; ".join(pieces)


def _image_tool_failed(output: Any) -> str | None:
    """图片工具失败时只把"失败原因"塞在字符串里, 不抛异常。手动抓出来。"""
    if isinstance(output, str) and "失败" in output:
        return output.strip()
    return None


def _try_image_tool(engine: str, tool_params: dict[str, Any], target: Path, *, retries: int = 2) -> str | None:
    """跑图片工具, 成功返回 None, 失败返回错误描述. 自带 retries 次重试 (默认 2)."""
    last_err = ""
    for attempt in range(1, retries + 1):
        try:
            out = run_tool(engine, tool_params)
        except Exception as exc:
            last_err = f"{engine} 抛异常: {exc}"
        else:
            failure = _image_tool_failed(out)
            if failure:
                last_err = failure
            elif not target.is_file() or target.stat().st_size < 1024:
                last_err = f"{engine} 没产出有效图片 (size={target.stat().st_size if target.is_file() else 0})"
            else:
                return None
        if attempt < retries:
            print(f"[character] ⏳ {engine} 第 {attempt}/{retries} 次失败, 重试 (错误: {last_err[:200]})", flush=True)
    return last_err


# 引擎能力表: 是否支持图生图 (reference_image)
REF_CAPABLE_ENGINES = {"Seedream5ImageGeneratorTool", "Gemini3ProImageGeneratorTool"}
ALL_IMAGE_ENGINES = {"Seedream5ImageGeneratorTool", "Gemini3ProImageGeneratorTool", "GptImage2Tool"}


def _resolve_reference_image(raw: str) -> Path | None:
    if not raw or not raw.strip():
        return None
    p = Path(raw.strip()).expanduser()
    if not p.is_absolute():
        p = (ROOT / p).resolve()
    if not p.is_file():
        raise SystemExit(f"reference_image 不存在: {p}")
    return p


def generate_character_image(
    params: dict[str, Any],
    dirs: dict[str, Path],
    aspect_ratio: str,
    *,
    dry_run: bool,
    pose_reference: Path | None = None,
) -> Path:
    target = dirs["frames"] / "character.jpg"
    reference_image = _resolve_reference_image(str(params.get("reference_image") or ""))

    if dry_run:
        from PIL import Image, ImageDraw

        w, h = dimensions_for_aspect_ratio(aspect_ratio)
        if reference_image:
            # 把参考图等比缩到目标画幅做占位
            ref = Image.open(reference_image).convert("RGB")
            ref.thumbnail((w, h))
            canvas = Image.new("RGB", (w, h), (40, 40, 50))
            ox = (w - ref.size[0]) // 2
            oy = (h - ref.size[1]) // 2
            canvas.paste(ref, (ox, oy))
            draw = ImageDraw.Draw(canvas)
            label = "DRY-RUN\nREF+POSE" if pose_reference else "DRY-RUN\nREF IMG"
            draw.text((20, 20), label, fill=(230, 230, 230))
            canvas.save(target, "JPEG", quality=88)
        else:
            image = Image.new("RGB", (w, h), (50, 60, 70))
            draw = ImageDraw.Draw(image)
            draw.rectangle((w // 4, h // 6, w * 3 // 4, h * 5 // 6), outline=(230, 230, 230), width=6)
            label = "DRY-RUN\nPOSE-ONLY" if pose_reference else "DRY-RUN\nCHARACTER"
            draw.text((w // 4 + 16, h // 6 + 16), label, fill=(230, 230, 230))
            image.save(target, "JPEG", quality=88)
        return target

    requested = str(params.get("image_engine") or "Seedream5ImageGeneratorTool")
    if requested not in ALL_IMAGE_ENGINES:
        requested = "Seedream5ImageGeneratorTool"

    # 决定走哪条路:
    #   1) reference_image + pose_reference  → 双图 (身份+姿态对齐, 推荐, RunningHub 友好)
    #   2) reference_image  (没 pose)        → 单图 (旧的 v5/v6 行为)
    #   3) pose_reference (没 reference)     → 用 character_prompt 文字 + pose 图当构图参考
    #   4) 都没有                            → 纯文生图 (character_prompt 必填)

    ref_paths: list[str] = []
    prompt: str
    needs_ref_capable_engine = False

    if reference_image and pose_reference:
        # 注意 Seedream5 把 reference_image_paths 反序插入 multimodal, 实际模型里第一张是列表最后一张
        # 我们希望模型先看到 POSE 图 (取景/比例参考), 后看到 IDENTITY (身份强约束)
        # 所以列表顺序: [IDENTITY, POSE]  → 最终模型看到 [POSE, IDENTITY, text]
        ref_paths = [str(reference_image), str(pose_reference)]
        prompt = build_dual_reference_prompt(
            str(params.get("character_prompt") or ""),
            str(params.get("action_style") or ""),
        )
        needs_ref_capable_engine = True
        print("[character] 双图模式: IDENTITY=reference_image + POSE=video_first_frame")
    elif reference_image:
        ref_paths = [str(reference_image)]
        prompt = build_reference_character_prompt(
            str(params.get("character_prompt") or ""),
            str(params.get("action_style") or ""),
        )
        needs_ref_capable_engine = True
    elif pose_reference:
        # 没有用户给的角色图, 只有视频首帧 — 用 character_prompt 做身份, pose 做构图
        if not str(params.get("character_prompt") or "").strip():
            raise SystemExit(
                "缺少 character_prompt: 没传 reference_image 时必须给一句角色描述 (才能告诉模型主角是谁)"
            )
        ref_paths = [str(pose_reference)]
        prompt = build_dual_reference_prompt(
            str(params.get("character_prompt") or ""),
            str(params.get("action_style") or ""),
        )
        needs_ref_capable_engine = True
        print("[character] 仅 POSE 模式: 用 character_prompt 做身份 + video_first_frame 做姿态参考")
    else:
        # 纯文生图
        if not str(params.get("character_prompt") or "").strip():
            raise SystemExit(
                "缺少 character_prompt: 没传 reference_image 时必须给一句角色描述"
            )
        ref_paths = []
        prompt = build_character_prompt(
            str(params.get("character_prompt") or ""),
            str(params.get("action_style") or ""),
        )
        needs_ref_capable_engine = False

    # 决定 fallback 链
    if needs_ref_capable_engine:
        if requested not in REF_CAPABLE_ENGINES:
            print(
                f"[character] ⚠️ 引擎 {requested} 不支持参考图, 自动换 Seedream5ImageGeneratorTool"
            )
            requested = "Seedream5ImageGeneratorTool"
        other = (
            "Gemini3ProImageGeneratorTool"
            if requested == "Seedream5ImageGeneratorTool"
            else "Seedream5ImageGeneratorTool"
        )
        chain = [requested, other]
    else:
        other = (
            "Seedream5ImageGeneratorTool"
            if requested == "GptImage2Tool"
            else "GptImage2Tool"
        )
        chain = [requested, other]

    errors: list[str] = []
    for engine in chain:
        if target.exists():
            target.unlink()
        tool_params: dict[str, Any] = {
            "prompt": prompt,
            "output_path": str(target),
            "aspect_ratio": aspect_ratio,
            "quality": "hd",
        }
        if ref_paths and engine in REF_CAPABLE_ENGINES:
            tool_params["reference_image_paths"] = ref_paths
        err = _try_image_tool(engine, tool_params, target)
        if err is None:
            if len(ref_paths) == 2:
                mode = "双图(身份+姿态)"
            elif ref_paths:
                mode = "单图"
            else:
                mode = "文生图"
            print(f"[character] ✅ 使用引擎 {engine} {mode}成功: {target}")
            return target
        print(f"[character] ⚠️  {engine} 失败: {err[:300]}")
        errors.append(f"{engine}: {err[:400]}")

    raise RuntimeError(
        "角色图生成所有引擎都失败:\n  - " + "\n  - ".join(errors)
    )


def run_action_transfer(
    character_image: Path,
    reference_video: Path,
    output_video: Path,
    *,
    mode: str,
    aspect_ratio: str,
    duration_hint: int,
    action_style: str,
    dry_run: bool,
) -> dict[str, Any]:
    if dry_run:
        # 直接把参考视频复制成"动作迁移结果"占位
        shutil.copy2(reference_video, output_video)
        return {"status": "success", "output_path": str(output_video), "engine": "dry_run"}

    width, height = dimensions_for_aspect_ratio(aspect_ratio)
    if mode == "multi":
        prompt = (
            "多人按照参考视频中的动作同步表演, "
            f"画面 9:16 竖屏, {action_style or '保持原节奏'}"
        )
        return run_tool(
            "WanMultiPersonActionImitateTool",
            {
                "image_path": str(character_image),
                "video_path": str(reference_video),
                "output_path": str(output_video),
                "instance_type": "plus",
                "width": width if aspect_ratio == "9:16" else 576,
                "height": height if aspect_ratio == "9:16" else 1024,
                "positive_prompt": prompt,
            },
        )

    return run_tool(
        "ActionImitateTool",
        {
            "image_path": str(character_image),
            "video_path": str(reference_video),
            "output_path": str(output_video),
            "engine": "animate2",
            "enable_fallback": True,
            "chunk_duration": 8.0,
            "duration": max(4, int(duration_hint)),
            "width": width,
            "height": height,
        },
    )


def _suno_generate_bgm(query: str, audio_dir: Path) -> tuple[str, dict[str, Any]]:
    """用 Suno 生成一段 instrumental BGM (绕开在线搜没结果的情况)。

    需要 .env 配 SUNO_BASE_URL + SUNO_API_KEY。失败返回 ("", info)。
    """
    try:
        from custom_tools.music_generation.suno_music_tool import SunoMusicClient
    except Exception as exc:
        return "", {"status": "unavailable", "source": "suno", "reason": f"import failed: {exc}"}
    try:
        client = SunoMusicClient()
    except Exception as exc:
        return "", {"status": "unavailable", "source": "suno", "reason": f"client init failed: {exc}"}

    tags = query.strip() or "energetic percussion cinematic instrumental"
    try:
        result = client.generate_music_custom(
            prompt="",  # 纯音乐, 无歌词
            tags=tags,
            title=f"action_bgm_{datetime.now().strftime('%H%M%S')}",
            mv="chirp-crow",
            make_instrumental=True,
            wait_for_completion=True,
            max_wait_time=300,
            output_dir=str(audio_dir),
        )
    except Exception as exc:
        return "", {"status": "unavailable", "source": "suno", "reason": str(exc)}
    if not result.get("success"):
        return "", {"status": "unavailable", "source": "suno", "reason": result.get("error", "unknown")}
    songs = [s for s in (result.get("songs") or []) if s.get("local_path")]
    if not songs:
        return "", {"status": "unavailable", "source": "suno", "reason": "no local_path in Suno response"}
    path = songs[0]["local_path"]
    return path, {
        "status": "generated",
        "path": path,
        "query": tags,
        "source": "Suno (instrumental)",
    }


def resolve_bgm(query: str, audio_dir: Path, *, provider: str = "auto") -> tuple[str, dict[str, Any]]:
    """按 provider 路由 BGM 获取来源:
        provider="online" - 只走 MusicManager 在线搜 (Jamendo / Internet Archive)
        provider="suno"   - 直接 Suno 生成 instrumental
        provider="auto"   - 先在线搜, 没结果就 Suno 兜底 (默认, 最稳)
    """
    provider = (provider or "auto").lower()
    if provider not in {"auto", "online", "suno"}:
        provider = "auto"

    online_info: dict[str, Any] = {}
    if provider in {"auto", "online"}:
        try:
            from src.utils.music_utils import MusicManager
        except Exception as exc:
            online_info = {"status": "unavailable", "reason": f"music_utils import failed: {exc}"}
        else:
            selection = {
                "music_source": "online",
                "music_query": query.strip() or "energetic dance percussion instrumental",
                "needs_bgm": True,
            }
            path = MusicManager.resolve_online_music_path(selection, audio_dir)
            if path:
                return path, {
                    "status": "downloaded",
                    "path": path,
                    "query": selection["music_query"],
                    "source": "Jamendo or Internet Archive via MusicManager",
                }
            online_info = {"status": "unavailable", "source": "online_search"}

    if provider == "online":
        return "", online_info or {"status": "unavailable", "source": "online_search"}

    # provider == "suno" 或 auto 走到这 (在线搜没找到)
    print(f"[bgm] 在线搜没结果, 切换到 Suno 生成 (query='{query.strip() or 'auto'}', 大约 30-90s)")
    path, suno_info = _suno_generate_bgm(query, audio_dir)
    if path:
        return path, suno_info
    return "", {
        "status": "unavailable",
        "reason": "online search empty and Suno fallback also failed",
        "online": online_info,
        "suno": suno_info,
    }


def mix_bgm(action_video: Path, bgm_path: str, out_path: Path, *, bgm_volume: float) -> Path:
    raw_has_audio = has_audio_stream(action_video)
    if raw_has_audio:
        cmd = [
            "ffmpeg",
            "-y",
            "-i",
            str(action_video),
            "-stream_loop",
            "-1",
            "-i",
            bgm_path,
            "-filter_complex",
            f"[0:a]volume=1.0[a0];[1:a]volume={bgm_volume}[a1];"
            "[a0][a1]amix=inputs=2:duration=shortest:dropout_transition=0[a]",
            "-map",
            "0:v",
            "-map",
            "[a]",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            str(out_path),
        ]
    else:
        cmd = [
            "ffmpeg",
            "-y",
            "-i",
            str(action_video),
            "-stream_loop",
            "-1",
            "-i",
            bgm_path,
            "-filter_complex",
            f"[1:a]volume={bgm_volume}[a]",
            "-map",
            "0:v",
            "-map",
            "[a]",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            str(out_path),
        ]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return out_path


def write_artifact_manifest(run_dir: Path, media: dict[str, str], bgm_info: dict[str, Any]) -> Path:
    artifacts = []
    for key, category, title in [
        ("release_video", "final_video", "Final action transfer video"),
        ("action_raw", "raw_video", "Raw RunningHub output"),
        ("reference", "source_video", "Reference action video"),
        ("reference_image", "source_image", "Reference character image (identity)"),
        ("pose_reference", "source_image", "Pose reference frame from video"),
        ("character", "first_frame", "Character source image"),
        ("local_video_qa", "qa", "Local video QA report"),
        ("run_notes", "qa", "Run notes"),
    ]:
        path = media.get(key)
        if path and Path(path).exists():
            artifacts.append(
                {
                    "category": category,
                    "path": path,
                    "title": title,
                    "size_bytes": Path(path).stat().st_size,
                }
            )
    payload = {
        "schema_version": 1,
        "workflow": "action_transfer_dance_v1",
        "artifacts": artifacts,
        "final_video": media.get("release_video", ""),
        "raw_video": media.get("action_raw", ""),
        "reference_video": media.get("reference", ""),
        "reference_image": media.get("reference_image", ""),
        "pose_reference": media.get("pose_reference", ""),
        "character_image": media.get("character", ""),
        "bgm": bgm_info,
    }
    path = run_dir / "artifact_manifest.json"
    write_json(path, payload)
    return path


def run_local_video_qa(run_dir: Path, aspect_ratio: str, *, expect_audio: bool, min_duration: float) -> str:
    output = run_dir / "qa" / "local_video_qa.json"
    manifest = run_dir / "artifact_manifest.json"
    cmd = [
        sys.executable,
        str(SCRIPTS / "local_video_qa.py"),
        "--run-dir",
        str(run_dir),
        "--manifest",
        str(manifest),
        "--aspect-ratio",
        aspect_ratio,
        "--min-duration",
        f"{min_duration}",
        "--output",
        str(output),
    ]
    if expect_audio:
        cmd.append("--expect-audio")
    result = subprocess.run(cmd, cwd=str(ROOT), text=True, capture_output=True)
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout[-1200:]
        # 把错误写到 qa 文件, 别让整个流程崩
        write_json(output, {"ok": False, "error": detail})
    return str(output)


def _now_hhmmss() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _step(msg: str) -> None:
    print(f"\n[{_now_hhmmss()}] ▶ {msg}", flush=True)


def run(params: dict[str, Any], output_dir: Path, *, dry_run: bool) -> dict[str, Any]:
    # 立即解开 Python 输出缓存, 让所有 print 实时可见
    try:
        sys.stdout.reconfigure(line_buffering=True)
        sys.stderr.reconfigure(line_buffering=True)
    except Exception:
        pass

    # Seedream5 双图模式 (我们的 v7 默认) 经常要 4-7 分钟, 默认 240s 超时容易炸; 显式抬到 600s.
    os.environ.setdefault("SEEDREAM5_READ_TIMEOUT", "600")

    aspect_ratio = str(params.get("aspect_ratio") or "").strip()
    aspect_ratio_explicit = bool(aspect_ratio)
    target_duration = int(params.get("target_duration") or 12)
    target_duration = max(4, min(target_duration, 20))
    add_bgm = bool(params.get("add_bgm", True))
    mode = str(params.get("single_or_multi_person") or "single").lower()
    if mode not in {"single", "multi"}:
        mode = "single"

    reference_raw = str(params.get("reference_video") or "").strip()
    if not reference_raw:
        reference_raw = str(DEFAULT_REFERENCE_VIDEO)
    reference_src = Path(reference_raw).expanduser()
    if not reference_src.is_absolute():
        reference_src = (ROOT / reference_src).resolve()
    if not reference_src.is_file():
        raise SystemExit(f"reference_video 不存在: {reference_src}")

    dirs = ensure_run_dirs(output_dir)
    run_notes_path = dirs["qa"] / "run_notes.json"
    bgm_info: dict[str, Any] = {"status": "not_used"}

    # 用户没显式给比例时, 跟随参考视频自身比例 (避免 9:16 强转 16:9 拉扯)
    if not aspect_ratio_explicit:
        aspect_ratio = detect_video_aspect_ratio(reference_src)

    _step(f"开始 action_transfer (dry_run={dry_run}, mode={mode}, target_duration={target_duration}s, aspect={aspect_ratio})")
    print(f"      run_dir = {output_dir}", flush=True)

    try:
        _step(f"step 1/6  归档 + 裁剪参考视频 → inputs/{reference_src.name} (上限 {target_duration}s)")
        reference_local = trim_reference_video(
            reference_src, dirs["inputs"] / reference_src.name, float(target_duration)
        )

        # step 1.5: 抽参考视频的姿态参考帧 (用 0.5s 那一帧, 避开开机黑帧)
        _step("step 2/6  抽参考视频 0.5s 处一帧 → inputs/pose_reference.jpg (用来对齐角色姿态/构图/比例)")
        pose_reference: Path | None = None
        try:
            pose_reference = extract_first_frame(
                reference_local, dirs["inputs"] / "pose_reference.jpg", at_seconds=0.5
            )
            print(f"      pose_reference = {pose_reference}", flush=True)
        except Exception as exc:
            print(f"      ⚠️  抽姿态帧失败 ({exc}), 退化到单图模式", flush=True)
            pose_reference = None

        # 把 reference_image (如果有) 也归档到 inputs/, 方便复盘
        ref_image_src = _resolve_reference_image(str(params.get("reference_image") or ""))
        ref_image_local: Path | None = None
        if ref_image_src:
            _step(f"step 3/6  归档参考角色图 → inputs/reference_image{ref_image_src.suffix.lower()}")
            ref_image_local = dirs["inputs"] / f"reference_image{ref_image_src.suffix.lower() or '.img'}"
            shutil.copy2(ref_image_src, ref_image_local)
            # 把归档后的本地路径塞回去, 让 generate_character_image 用归档版
            params = dict(params)
            params["reference_image"] = str(ref_image_local)
        else:
            _step("step 3/6  没有 reference_image (将仅靠 character_prompt + 姿态参考帧 生成)")

        _step(f"step 4/6  生成 {aspect_ratio} 全身角色锚定图 (双图模式: 身份+姿态对齐, 通常 30s-2min)")
        character = generate_character_image(
            params, dirs, aspect_ratio, dry_run=dry_run, pose_reference=pose_reference
        )

        _step(f"step 5/6  RunningHub 动作迁移 (这一步通常 5-10 分钟, 请耐心等)")
        action_raw = dirs["videos"] / "action_raw.mp4"
        run_action_transfer(
            character_image=character,
            reference_video=reference_local,
            output_video=action_raw,
            mode=mode,
            aspect_ratio=aspect_ratio,
            duration_hint=target_duration,
            action_style=str(params.get("action_style") or ""),
            dry_run=dry_run,
        )
        if not action_raw.is_file():
            raise RuntimeError(f"动作迁移没产物: {action_raw}")

        _step(f"step 6/6  组装 release/video.mp4 (BGM={'on' if add_bgm else 'off'})")
        release_video = dirs["release"] / "video.mp4"
        if add_bgm and not dry_run:
            bgm_path, bgm_info = resolve_bgm(
                str(params.get("bgm_query") or ""),
                dirs["audio"],
                provider=str(params.get("bgm_provider") or "auto"),
            )
            if bgm_path:
                mix_bgm(action_raw, bgm_path, release_video, bgm_volume=0.18)
            else:
                shutil.copy2(action_raw, release_video)
        else:
            shutil.copy2(action_raw, release_video)
            if not add_bgm:
                bgm_info = {"status": "disabled_by_param"}
            elif dry_run:
                bgm_info = {"status": "dry_run"}

        media = {
            "release_video": str(release_video),
            "action_raw": str(action_raw),
            "reference": str(reference_local),
            "character": str(character),
        }
        if ref_image_local:
            media["reference_image"] = str(ref_image_local)
        if pose_reference:
            media["pose_reference"] = str(pose_reference)
        write_json(
            run_notes_path,
            {
                "status": "success",
                "dry_run": dry_run,
                "mode": mode,
                "aspect_ratio": aspect_ratio,
                "aspect_ratio_explicit": aspect_ratio_explicit,
                "target_duration": target_duration,
                "reference_video": str(reference_local),
                "reference_image": str(ref_image_local) if ref_image_local else None,
                "pose_reference": str(pose_reference) if pose_reference else None,
                "character_prompt": str(params.get("character_prompt") or ""),
                "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            },
        )
        media["run_notes"] = str(run_notes_path)
        # 先写 manifest, QA 才能找到 artifact_manifest.json
        write_artifact_manifest(output_dir, media, bgm_info)
        # min_duration: 取 release video 实际时长的 90%, 保底 1s
        try:
            actual_dur = ffprobe_duration(release_video)
        except Exception:
            actual_dur = float(target_duration)
        min_duration = max(1.0, actual_dur * 0.9)
        # 用 release 视频的"实际"比例做 QA 期望值, 而不是我们一开始 request 的
        # 原因: RunningHub 的 animate4 引擎只支持 720x1280, 会无视我们的请求强转 9:16
        # 把"想要"的比例和"实际"的比例不匹配当成 QA fail 没意义, 用户拿到的是实际视频
        actual_aspect_ratio = detect_video_aspect_ratio(release_video)
        if actual_aspect_ratio != aspect_ratio:
            print(
                f"[qa] ⚠️ 注意: 你请求 {aspect_ratio} 但 RunningHub 引擎只支持 {actual_aspect_ratio} "
                f"(动作迁移引擎的硬性限制), 最终视频实际是 {actual_aspect_ratio}", flush=True
            )
        media["local_video_qa"] = run_local_video_qa(
            output_dir, actual_aspect_ratio,
            expect_audio=has_audio_stream(release_video),
            min_duration=min_duration,
        )
        manifest = write_artifact_manifest(output_dir, media, bgm_info)
        return {
            "workspace_dir": str(output_dir),
            "manifest": str(manifest),
            "final_video": str(release_video),
            "bgm": bgm_info,
        }
    except Exception as exc:
        write_json(
            run_notes_path,
            {
                "status": "failed",
                "dry_run": dry_run,
                "error": str(exc),
                "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            },
        )
        write_artifact_manifest(output_dir, {"run_notes": str(run_notes_path)}, bgm_info)
        raise SystemExit(str(exc)) from exc


def load_params(args: argparse.Namespace) -> dict[str, Any]:
    if args.params and args.params.strip().startswith("{"):
        return json.loads(args.params)
    if args.params:
        p = Path(args.params).expanduser()
        if p.is_file():
            return json.loads(p.read_text(encoding="utf-8"))
    if not sys.stdin.isatty():
        raw = sys.stdin.read()
        if raw.strip().startswith("{"):
            return json.loads(raw)
    return {}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="action_transfer_dance_v1 本地编排脚本")
    parser.add_argument("--params", default="", help="JSON 字符串或 JSON 文件路径")
    parser.add_argument("--output-dir", required=True, help="run 目录")
    parser.add_argument("--dry-run", action="store_true", help="不调付费 API, 只串通管线")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    params = load_params(args)
    output_dir = Path(args.output_dir).expanduser().resolve()
    result = run(params, output_dir, dry_run=args.dry_run or bool(params.get("dry_run")))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
