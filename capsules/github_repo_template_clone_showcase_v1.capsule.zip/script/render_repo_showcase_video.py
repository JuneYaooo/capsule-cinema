#!/usr/bin/env python3
"""Render a source-grounded GitHub/repo showcase profile into a 6:7 video.

This is a deterministic local renderer for capsule-driven repo showcase runs.
It expects the agent to do the project-specific judgment first, then pass a
small JSON profile with titles, scene cards, source image paths, and voiceover.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps


W, H = 1080, 1260
FONT_REG_CANDIDATES = [
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/STHeiti Light.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
]
FONT_BOLD_CANDIDATES = [
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
]


def run(cmd: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, capture_output=True, check=check)


def font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    for candidate in FONT_BOLD_CANDIDATES if bold else FONT_REG_CANDIDATES:
        path = Path(candidate)
        if path.exists():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default(size=size)


def text_size(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.FreeTypeFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[2] - box[0], box[3] - box[1]


def wrap_text(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.FreeTypeFont, max_w: int) -> list[str]:
    lines: list[str] = []
    for raw in str(text).split("\n"):
        current = ""
        for ch in raw:
            candidate = current + ch
            if text_size(draw, candidate, fnt)[0] <= max_w or not current:
                current = candidate
            else:
                lines.append(current)
                current = ch
        if current:
            lines.append(current)
    return lines


def draw_centered(
    draw: ImageDraw.ImageDraw,
    text: str,
    y: int,
    fnt: ImageFont.FreeTypeFont,
    fill: str,
    *,
    line_gap: int = 0,
    stroke_width: int = 0,
    stroke_fill: str = "#000000",
    canvas_w: int = W,
) -> int:
    yy = y
    for line in str(text).split("\n"):
        tw, th = text_size(draw, line, fnt)
        draw.text(
            ((canvas_w - tw) / 2, yy),
            line,
            font=fnt,
            fill=fill,
            stroke_width=stroke_width,
            stroke_fill=stroke_fill,
        )
        yy += th + line_gap
    return yy


def rounded(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    radius: int,
    fill: str | tuple[int, int, int, int] | None,
    outline: str | tuple[int, int, int, int] | None = None,
    width: int = 1,
) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def make_bg(accent: str) -> Image.Image:
    bg = Image.new("RGBA", (W, H), "#020810")
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    try:
        rgb = tuple(int(accent[i : i + 2], 16) for i in (1, 3, 5))
    except Exception:
        rgb = (22, 122, 111)
    gd.ellipse((120, -260, 960, 360), fill=rgb + (42,))
    gd.ellipse((650, 140, 1280, 760), fill=(42, 163, 217, 26))
    gd.ellipse((-220, 560, 440, 1300), fill=(232, 183, 48, 18))
    bg.alpha_composite(glow.filter(ImageFilter.GaussianBlur(90)))
    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    for y in range(86, H - 145, 56):
        gd.line((0, y, W, y), fill=(38, 82, 128, 52), width=1)
    for x in range(0, W, 86):
        gd.line((x, 70, x, H - 150), fill=(38, 82, 128, 45), width=1)
    for x in range(-260, W, 110):
        gd.line((x, 70, x + 360, H - 150), fill=(40, 150, 230, 45), width=1)
    bg.alpha_composite(grid)
    draw = ImageDraw.Draw(bg)
    draw.rectangle((0, 0, W, 46), fill="#1D2525")
    draw.rectangle((0, H - 150, W, H), fill="#1D2525")
    return bg


def fit_image(src: Image.Image, box: tuple[int, int, int, int], mode: str = "contain") -> Image.Image:
    bw = box[2] - box[0]
    bh = box[3] - box[1]
    im = ImageOps.exif_transpose(src.convert("RGB"))
    scale = max(bw / im.width, bh / im.height) if mode == "cover" else min(bw / im.width, bh / im.height)
    return im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.Resampling.LANCZOS)


def paste_fit(
    canvas: Image.Image,
    src_path: Path,
    box: tuple[int, int, int, int],
    *,
    mode: str = "cover",
    bg: str = "#1F2929",
    radius: int = 16,
    outline: str = "#1D2525",
) -> None:
    x1, y1, x2, y2 = box
    layer = Image.new("RGBA", (x2 - x1, y2 - y1), bg)
    im = fit_image(Image.open(src_path), box, mode=mode).convert("RGBA")
    layer.alpha_composite(im, ((layer.width - im.width) // 2, (layer.height - im.height) // 2))
    mask = Image.new("L", layer.size, 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle((0, 0, layer.width - 1, layer.height - 1), radius=radius, fill=255)
    layer.putalpha(mask)
    canvas.alpha_composite(layer, (x1, y1))
    rounded(ImageDraw.Draw(canvas), box, radius, None, outline=outline, width=2)


def draw_title(draw: ImageDraw.ImageDraw, profile: dict[str, Any], scene: dict[str, Any]) -> None:
    accent = scene.get("accent") or profile.get("accent") or "#167A6F"
    tag = scene.get("tag") or profile.get("tag") or "repo showcase"
    tag_f = font(24, True)
    tw, th = text_size(draw, tag, tag_f)
    rounded(draw, (int((W - tw) / 2 - 24), 78, int((W + tw) / 2 + 24), 78 + th + 16), 18, "#1D2525", accent, 2)
    draw.text(((W - tw) / 2, 84), tag, font=tag_f, fill="#F7F2DE")
    draw_centered(draw, profile["top_title"], 132, font(64, True), "#FFFFFF", line_gap=-2, stroke_width=3, stroke_fill="#05070B")
    draw_centered(draw, profile.get("top_subtitle", ""), 286, font(28, True), "#CFE7F7")


def draw_metric_card(draw: ImageDraw.ImageDraw, x: int, y: int, metric: dict[str, Any], accent: str) -> None:
    rounded(draw, (x, y, x + 190, y + 104), 18, "#FFFDF6", accent, 2)
    draw.text((x + 20, y + 16), str(metric.get("value", "")), font=font(40, True), fill="#15191A")
    draw.text((x + 20, y + 66), str(metric.get("label", "")), font=font(22), fill="#40504B")


def draw_visual(canvas: Image.Image, profile: dict[str, Any], scene: dict[str, Any]) -> None:
    draw = ImageDraw.Draw(canvas)
    accent = scene.get("accent") or profile.get("accent") or "#167A6F"
    rounded(draw, (84, 342, 996, 820), 24, "#FFFDF6", accent, 3)
    title = scene.get("visual_title") or scene.get("bottom_title") or profile.get("project_name", "")
    draw_centered(draw, title, 382, font(42, True), "#15191A")

    images = [Path(item) for item in scene.get("image_paths", []) if item]
    images = [item for item in images if item.exists()]
    if images:
        boxes = [(118, 470, 510, 640), (570, 470, 962, 640), (118, 668, 510, 798), (570, 668, 962, 798)]
        labels = scene.get("image_labels", [])
        for idx, path in enumerate(images[:4]):
            paste_fit(canvas, path, boxes[idx], outline=accent)
            if idx < len(labels):
                x1, y1, _, _ = boxes[idx]
                rounded(draw, (x1 + 12, y1 + 12, x1 + 158, y1 + 46), 12, "#1D2525", accent, 1)
                draw.text((x1 + 24, y1 + 16), str(labels[idx]), font=font(20, True), fill="#F7F2DE")
        return

    metrics = scene.get("metrics") or profile.get("metrics") or []
    for idx, metric in enumerate(metrics[:4]):
        draw_metric_card(draw, 130 + idx * 215, 520, metric, metric.get("accent") or accent)

    bullets = scene.get("visual_lines") or []
    yy = 670
    for line in bullets[:4]:
        rounded(draw, (150, yy, 930, yy + 45), 14, "#1F2929", accent, 1)
        draw_centered(draw, line, yy + 8, font(24, True), "#FFFFFF")
        yy += 58


def draw_bottom(canvas: Image.Image, scene: dict[str, Any]) -> None:
    draw = ImageDraw.Draw(canvas)
    accent = scene.get("accent") or "#167A6F"
    y1, y2 = 876, 1072
    rounded(draw, (76, y1, 1004, y2), 22, "#1F2929", accent, 3)
    draw.rectangle((430, y1 - 3, 650, y1 + 7), fill=accent)
    draw_centered(draw, scene.get("bottom_title", ""), y1 + 28, font(38, True), "#FFFFFF")
    yy = y1 + 88
    for line in scene.get("bottom_lines", []):
        for wrapped in wrap_text(draw, line, font(27), 820):
            tw, _ = text_size(draw, wrapped, font(27))
            draw.text(((W - tw) / 2, yy), wrapped, font=font(27), fill="#DCE7E1")
            yy += 34
    footer = scene.get("footer", "")
    if footer:
        foot_f = font(21, True)
        tw, _ = text_size(draw, footer, foot_f)
        rounded(draw, (int((W - tw) / 2 - 18), y2 - 38, int((W + tw) / 2 + 18), y2 - 11), 12, "#F6F3EA")
        draw.text(((W - tw) / 2, y2 - 38), footer, font=foot_f, fill=accent)


def render_frame(profile: dict[str, Any], scene: dict[str, Any], out: Path) -> None:
    canvas = make_bg(scene.get("accent") or profile.get("accent") or "#167A6F")
    draw = ImageDraw.Draw(canvas)
    draw_title(draw, profile, scene)
    draw_visual(canvas, profile, scene)
    draw_bottom(canvas, scene)
    canvas.convert("RGB").save(out, quality=95)


def ffprobe_duration(path: Path) -> float:
    proc = run([
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        str(path),
    ])
    return float(proc.stdout.strip())


def find_project_root() -> Path:
    env_root = os.environ.get("CAPSULE_CINEMA_ROOT") or os.environ.get("VIDEO_AGENT_ROOT")
    candidates: list[Path] = []
    if env_root:
        candidates.append(Path(env_root).expanduser())
    candidates.extend([Path.cwd(), Path(__file__).resolve()])
    for start in candidates:
        current = start if start.is_dir() else start.parent
        for parent in (current, *current.parents):
            if (parent / "scripts" / "env_loader.py").exists() and (parent / "lib").exists():
                return parent.resolve()
    raise SystemExit(
        "Cannot locate Capsule Cinema project root. Run from the repo root or set CAPSULE_CINEMA_ROOT."
    )


def synthesize_tts(root: Path, text: str, out: Path, speed: float) -> dict[str, Any]:
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(root / "lib"))
    from scripts.env_loader import load_video_agent_env

    load_video_agent_env(root / "scripts")
    from custom_tools.audio_generation.minimax_tts_tool import synthesize_with_minimax

    result = synthesize_with_minimax(
        text,
        str(out),
        voice_type="zh_male_jieshuoxiaoming_moon_bigtts",
        speed=speed,
    )
    if result.get("success"):
        result["duration"] = ffprobe_duration(out)
    return result


def write_concat(frames: list[Path], durations: list[float], out: Path) -> None:
    with out.open("w", encoding="utf-8") as handle:
        for frame, duration in zip(frames, durations):
            handle.write(f"file '{frame.resolve()}'\n")
            handle.write(f"duration {duration:.3f}\n")
        handle.write(f"file '{frames[-1].resolve()}'\n")
        handle.write("duration 0.033\n")
        handle.write(f"file '{frames[-1].resolve()}'\n")


def write_prompt_snapshots(profile: dict[str, Any], output_dir: Path, params_path: Path, topic: str) -> list[dict[str, Any]]:
    prompts_dir = output_dir / "prompts"
    render_dir = prompts_dir / "render"
    render_dir.mkdir(parents=True, exist_ok=True)

    profile_snapshot = render_dir / "repo_showcase_profile_v001.json"
    snapshot = {
        "type": "repo_showcase_profile",
        "topic": topic,
        "source_params_path": str(params_path),
        "profile": profile,
    }
    profile_snapshot.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    prompt_index = prompts_dir / "prompt_index.json"
    index = {
        "schema": "capsule_cinema.prompt_index.v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "entries": [
            {
                "id": "repo_showcase_profile_v001",
                "category": "render",
                "path": str(profile_snapshot.relative_to(output_dir)),
                "source_params_path": str(params_path),
            }
        ],
    }
    prompt_index.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return [
        {"path": str(prompt_index.resolve()), "category": "storyboard_prompt", "title": "Prompt index"},
        {"path": str(profile_snapshot.resolve()), "category": "storyboard_prompt", "title": "Repo showcase profile"},
    ]


def render_video(profile: dict[str, Any], output_dir: Path, root: Path, params_path: Path, topic: str) -> dict[str, Any]:
    release_dir = output_dir / "release"
    work_dir = output_dir / "work"
    frames_dir = work_dir / "frames"
    audio_dir = work_dir / "audio"
    qa_dir = output_dir / "qa"
    tmp_dir = work_dir / "tmp"
    for directory in (release_dir, frames_dir, audio_dir, qa_dir, tmp_dir):
        directory.mkdir(parents=True, exist_ok=True)

    scenes = profile.get("scenes") or []
    if not scenes:
        raise SystemExit("params profile must include scenes")

    frames: list[Path] = []
    for idx, scene in enumerate(scenes, start=1):
        out = frames_dir / f"frame_{idx:02d}.png"
        render_frame(profile, scene, out)
        frames.append(out)

    voiceover = profile.get("voiceover", "")
    if not voiceover and profile.get("voiceover_required", True):
        raise SystemExit("voiceover is required")

    tts_status: dict[str, Any] = {"requested": bool(voiceover), "success": False}
    duration = float(profile.get("target_duration", 60))
    if voiceover:
        tts_path = audio_dir / "voiceover.mp3"
        tts_status = synthesize_tts(root, voiceover, tts_path, float(profile.get("tts_speed", 1.24)))
        if not tts_status.get("success"):
            raise SystemExit(f"TTS failed: {tts_status.get('error') or tts_status}")
        duration = float(tts_status["duration"])

    weights = [max(1, len(str(scene.get("narration", scene.get("bottom_title", ""))))) for scene in scenes]
    raw = [duration * weight / sum(weights) for weight in weights]
    durations = [max(3.5, item) for item in raw]
    scale = duration / sum(durations)
    durations = [item * scale for item in durations]

    concat = tmp_dir / "frames.txt"
    visual = tmp_dir / "visual.mp4"
    write_concat(frames, durations, concat)
    run([
        "ffmpeg",
        "-y",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        str(concat),
        "-vf",
        "fps=30,format=yuv420p",
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        str(visual),
    ])

    final_video = release_dir / "video.mp4"
    if voiceover:
        run([
            "ffmpeg",
            "-y",
            "-i",
            str(visual),
            "-i",
            str(audio_dir / "voiceover.mp3"),
            "-map",
            "0:v",
            "-map",
            "1:a",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            "-movflags",
            "+faststart",
            str(final_video),
        ])
    else:
        run(["ffmpeg", "-y", "-i", str(visual), "-c:v", "copy", "-an", "-movflags", "+faststart", str(final_video)])

    copy_path = release_dir / "copy.txt"
    copy_path.write_text(profile.get("copy", profile.get("top_title", "")) + "\n", encoding="utf-8")
    prompt_artifacts = write_prompt_snapshots(profile, output_dir, params_path, topic)
    run_notes = {
        "ok": True,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "topic": topic,
        "tts_status": tts_status,
        "frame_count": len(frames),
        "duration": ffprobe_duration(final_video),
    }
    run_notes_path = qa_dir / "run_notes.json"
    run_notes_path.write_text(json.dumps(run_notes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    manifest = {
        "artifacts": [
            {"path": str(final_video.resolve()), "category": "final_video", "title": "Final video"},
            {"path": str(copy_path.resolve()), "category": "copywriting", "title": "Copywriting"},
            {"path": str(run_notes_path.resolve()), "category": "run_notes", "title": "Run notes"},
            *prompt_artifacts,
        ]
    }
    (output_dir / "artifact_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return run_notes


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topic", default="")
    parser.add_argument("--params", required=True, help="Path to repo showcase profile JSON.")
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = find_project_root()
    params_path = Path(args.params).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    profile = json.loads(params_path.read_text(encoding="utf-8"))
    if args.topic and "topic" not in profile:
        profile["topic"] = args.topic
    render_video(profile, output_dir, root, params_path, args.topic or profile.get("topic", ""))


if __name__ == "__main__":
    main()
