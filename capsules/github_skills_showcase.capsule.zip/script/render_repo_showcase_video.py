#!/usr/bin/env python3
"""Render a source-grounded GitHub/repo showcase profile into a 6:7 video.

This is a deterministic local renderer for capsule-driven repo showcase runs.
It expects the agent to do the project-specific judgment first, then pass a
small JSON profile with titles, scene cards, source image paths, and voiceover.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps


W, H = 1080, 1260
FONT_REG_CANDIDATES = [
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/STHeiti Light.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
]
FONT_BOLD_CANDIDATES = [
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
]


def run(cmd: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, capture_output=True, check=check)


def font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    for candidate in FONT_BOLD_CANDIDATES if bold else FONT_REG_CANDIDATES:
        path = Path(candidate)
        if path.exists():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default(size=size)


def text_size(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.FreeTypeFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[2] - box[0], box[3] - box[1]


def multiline_size(
    draw: ImageDraw.ImageDraw,
    text: str,
    fnt: ImageFont.FreeTypeFont,
    *,
    line_gap: int = 0,
) -> tuple[int, int]:
    lines = str(text).split("\n") or [""]
    widths: list[int] = []
    heights: list[int] = []
    for line in lines:
        tw, th = text_size(draw, line, fnt)
        widths.append(tw)
        heights.append(th)
    return max(widths or [0]), sum(heights) + max(0, len(lines) - 1) * line_gap


def fit_font_size(
    draw: ImageDraw.ImageDraw,
    text: str,
    *,
    start: int,
    minimum: int,
    max_w: int,
    max_h: int | None = None,
    bold: bool = False,
    line_gap: int = 0,
) -> ImageFont.ImageFont:
    size = start
    while size > minimum:
        candidate = font(size, bold)
        tw, th = multiline_size(draw, text, candidate, line_gap=line_gap)
        if tw <= max_w and (max_h is None or th <= max_h):
            return candidate
        size -= 2
    return font(minimum, bold)


def wrap_text(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.FreeTypeFont, max_w: int) -> list[str]:
    lines: list[str] = []
    for raw in str(text).split("\n"):
        current = ""
        for ch in raw:
            candidate = current + ch
            if text_size(draw, candidate, fnt)[0] <= max_w or not current:
                current = candidate
            else:
                lines.append(current)
                current = ch
        if current:
            lines.append(current)
    return lines


def draw_centered(
    draw: ImageDraw.ImageDraw,
    text: str,
    y: int,
    fnt: ImageFont.FreeTypeFont,
    fill: str,
    *,
    line_gap: int = 0,
    stroke_width: int = 0,
    stroke_fill: str = "#000000",
    canvas_w: int = W,
) -> int:
    yy = y
    for line in str(text).split("\n"):
        tw, th = text_size(draw, line, fnt)
        draw.text(
            ((canvas_w - tw) / 2, yy),
            line,
            font=fnt,
            fill=fill,
            stroke_width=stroke_width,
            stroke_fill=stroke_fill,
        )
        yy += th + line_gap
    return yy


def draw_centered_in_box(
    draw: ImageDraw.ImageDraw,
    text: str,
    box: tuple[int, int, int, int],
    fnt: ImageFont.FreeTypeFont,
    fill: str,
    *,
    line_gap: int = 0,
) -> int:
    x1, y1, x2, _ = box
    yy = y1
    for line in str(text).split("\n"):
        tw, th = text_size(draw, line, fnt)
        draw.text((x1 + (x2 - x1 - tw) / 2, yy), line, font=fnt, fill=fill)
        yy += th + line_gap
    return yy


def rounded(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    radius: int,
    fill: str | tuple[int, int, int, int] | None,
    outline: str | tuple[int, int, int, int] | None = None,
    width: int = 1,
) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def make_bg(accent: str) -> Image.Image:
    bg = Image.new("RGBA", (W, H), "#020810")
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    try:
        rgb = tuple(int(accent[i : i + 2], 16) for i in (1, 3, 5))
    except Exception:
        rgb = (22, 122, 111)
    gd.ellipse((120, -260, 960, 360), fill=rgb + (42,))
    gd.ellipse((650, 140, 1280, 760), fill=(42, 163, 217, 26))
    gd.ellipse((-220, 560, 440, 1300), fill=(232, 183, 48, 18))
    bg.alpha_composite(glow.filter(ImageFilter.GaussianBlur(90)))
    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    for y in range(86, H - 145, 56):
        gd.line((0, y, W, y), fill=(38, 82, 128, 52), width=1)
    for x in range(0, W, 86):
        gd.line((x, 70, x, H - 150), fill=(38, 82, 128, 45), width=1)
    for x in range(-260, W, 110):
        gd.line((x, 70, x + 360, H - 150), fill=(40, 150, 230, 45), width=1)
    bg.alpha_composite(grid)
    draw = ImageDraw.Draw(bg)
    draw.rectangle((0, 0, W, 46), fill="#1D2525")
    draw.rectangle((0, H - 150, W, H), fill="#1D2525")
    return bg


def fit_image(src: Image.Image, box: tuple[int, int, int, int], mode: str = "contain") -> Image.Image:
    bw = box[2] - box[0]
    bh = box[3] - box[1]
    im = ImageOps.exif_transpose(src.convert("RGB"))
    scale = max(bw / im.width, bh / im.height) if mode == "cover" else min(bw / im.width, bh / im.height)
    return im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.Resampling.LANCZOS)


def paste_fit(
    canvas: Image.Image,
    src_path: Path,
    box: tuple[int, int, int, int],
    *,
    mode: str = "cover",
    bg: str = "#1F2929",
    radius: int = 16,
    outline: str = "#1D2525",
    motion_progress: float = 0.0,
    motion_direction: str = "zoom_in",
    motion_amount: float = 0.0,
) -> None:
    x1, y1, x2, y2 = box
    layer = Image.new("RGBA", (x2 - x1, y2 - y1), bg)
    im = fit_image(Image.open(src_path), box, mode=mode).convert("RGBA")
    progress = min(1.0, max(0.0, motion_progress))
    eased = 0.5 - math.cos(progress * math.pi) / 2
    if motion_amount > 0:
        if motion_direction == "scale_in":
            scale = max(0.75, 1.0 - motion_amount) + (motion_amount * 1.18) * eased
        elif motion_direction == "zoom_out":
            scale = 1.0 + motion_amount * (1.0 - eased)
        else:
            scale = 1.0 + motion_amount * eased
        if scale != 1.0:
            im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.Resampling.LANCZOS)

    base_x = (layer.width - im.width) // 2
    base_y = (layer.height - im.height) // 2
    shift = int(28 * eased)
    if motion_direction == "pan_left":
        base_x += shift
    elif motion_direction == "pan_right":
        base_x -= shift
    elif motion_direction == "pan_up":
        base_y += shift
    elif motion_direction == "pan_down":
        base_y -= shift
    elif motion_direction == "cut_in_left":
        base_x -= int(layer.width * 0.18 * (1.0 - eased))
    elif motion_direction == "cut_in_right":
        base_x += int(layer.width * 0.18 * (1.0 - eased))
    elif motion_direction == "cut_in_bottom":
        base_y += int(layer.height * 0.20 * (1.0 - eased))

    layer.alpha_composite(im, (base_x, base_y))
    mask = Image.new("L", layer.size, 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle((0, 0, layer.width - 1, layer.height - 1), radius=radius, fill=255)
    layer.putalpha(mask)
    canvas.alpha_composite(layer, (x1, y1))
    rounded(ImageDraw.Draw(canvas), box, radius, None, outline=outline, width=2)


def existing_image_paths(scene: dict[str, Any]) -> list[Path]:
    images = [Path(item) for item in scene.get("image_paths", []) if item]
    return [item for item in images if item.exists()]


def draw_title(draw: ImageDraw.ImageDraw, profile: dict[str, Any], scene: dict[str, Any]) -> None:
    accent = scene.get("accent") or profile.get("accent") or "#167A6F"
    tag = scene.get("tag") or profile.get("tag") or "repo showcase"
    tag_f = font(24, True)
    tw, th = text_size(draw, tag, tag_f)
    rounded(draw, (int((W - tw) / 2 - 24), 78, int((W + tw) / 2 + 24), 78 + th + 16), 18, "#1D2525", accent, 2)
    draw.text(((W - tw) / 2, 84), tag, font=tag_f, fill="#F7F2DE")
    title_f = fit_font_size(
        draw,
        profile["top_title"],
        start=int(profile.get("top_title_font_size", 68)),
        minimum=46,
        max_w=940,
        max_h=140,
        bold=True,
        line_gap=-2,
    )
    title_end = draw_centered(
        draw,
        profile["top_title"],
        128,
        title_f,
        "#FFFFFF",
        line_gap=-2,
        stroke_width=3,
        stroke_fill="#05070B",
    )
    subtitle = profile.get("top_subtitle", "")
    if subtitle:
        subtitle_f = fit_font_size(
            draw,
            subtitle,
            start=int(profile.get("top_subtitle_font_size", 30)),
            minimum=22,
            max_w=940,
            max_h=44,
            bold=True,
        )
        draw_centered(draw, subtitle, max(286, title_end + 16), subtitle_f, "#CFE7F7")


def draw_metric_card(draw: ImageDraw.ImageDraw, x: int, y: int, metric: dict[str, Any], accent: str) -> None:
    rounded(draw, (x, y, x + 190, y + 104), 18, "#FFFDF6", accent, 2)
    draw.text((x + 20, y + 16), str(metric.get("value", "")), font=font(40, True), fill="#15191A")
    draw.text((x + 20, y + 66), str(metric.get("label", "")), font=font(22), fill="#40504B")


def draw_hero_value(draw: ImageDraw.ImageDraw, text: str, y: int, accent: str) -> int:
    fnt = fit_font_size(draw, text, start=52, minimum=34, max_w=760, max_h=74, bold=True, line_gap=2)
    _, block_h = multiline_size(draw, text, fnt, line_gap=2)
    rounded(draw, (132, y - 12, 948, y + block_h + 20), 20, "#1F2929", accent, 2)
    draw_centered(draw, text, y, fnt, "#FFFFFF", line_gap=2)
    return y + block_h + 28


def draw_value_badges(draw: ImageDraw.ImageDraw, badges: list[dict[str, Any]], y: int, accent: str) -> int:
    visible = [item for item in badges if item and (item.get("value") or item.get("text"))][:3]
    if not visible:
        return y

    gap = 18
    if len(visible) == 1:
        card_w = 640
        x0 = int((W - card_w) / 2)
    else:
        card_w = int((820 - gap * (len(visible) - 1)) / len(visible))
        x0 = int((W - (card_w * len(visible) + gap * (len(visible) - 1))) / 2)
    card_h = 118

    for idx, badge in enumerate(visible):
        x = x0 + idx * (card_w + gap)
        local_accent = badge.get("accent") or accent
        rounded(draw, (x, y, x + card_w, y + card_h), 18, "#1F2929", local_accent, 2)
        value = str(badge.get("value") or badge.get("text") or "")
        label = str(badge.get("label") or "")
        value_f = fit_font_size(
            draw,
            value,
            start=int(badge.get("font_size", 48)),
            minimum=26,
            max_w=card_w - 34,
            max_h=64,
            bold=True,
            line_gap=0,
        )
        _, value_h = multiline_size(draw, value, value_f)
        value_y = y + 18 if label else y + int((card_h - value_h) / 2) - 2
        draw_centered_in_box(draw, value, (x, value_y, x + card_w, y + card_h), value_f, "#FFFFFF")
        if label:
            label_f = fit_font_size(draw, label, start=22, minimum=16, max_w=card_w - 34, max_h=28)
            label_w, _ = text_size(draw, label, label_f)
            draw.text((x + (card_w - label_w) / 2, y + 82), label, font=label_f, fill="#CFE7F7")
    return y + card_h


def image_boxes_for_content(content_y: int, image_count: int) -> list[tuple[int, int, int, int]]:
    if content_y <= 500:
        if image_count <= 1:
            return [(118, 452, 962, 798)]
        if image_count <= 2:
            return [(118, 482, 510, 798), (570, 482, 962, 798)]
        return [(118, 470, 510, 640), (570, 470, 962, 640), (118, 668, 510, 798), (570, 668, 962, 798)]
    top = min(max(content_y + 24, 560), 660)
    if image_count <= 1:
        return [(150, top, 930, 798)]
    if image_count <= 2:
        return [(118, top, 510, 798), (570, top, 962, 798)]
    row_gap = 18
    row_h = max(74, int((798 - top - row_gap) / 2))
    return [
        (118, top, 510, top + row_h),
        (570, top, 962, top + row_h),
        (118, top + row_h + row_gap, 510, 798),
        (570, top + row_h + row_gap, 962, 798),
    ]


def draw_visual(canvas: Image.Image, profile: dict[str, Any], scene: dict[str, Any], progress: float = 0.0) -> None:
    draw = ImageDraw.Draw(canvas)
    accent = scene.get("accent") or profile.get("accent") or "#167A6F"
    rounded(draw, (84, 342, 996, 820), 24, "#FFFDF6", accent, 3)
    title = scene.get("visual_title") or scene.get("bottom_title") or profile.get("project_name", "")
    has_value_block = bool(scene.get("hero_value_text") or scene.get("value_badges"))
    draw_centered(draw, title, 372 if has_value_block else 382, font(36 if has_value_block else 42, True), "#15191A")

    content_y = 434 if has_value_block else 470
    if scene.get("hero_value_text"):
        content_y = draw_hero_value(draw, str(scene["hero_value_text"]), content_y, accent) + 8
    if scene.get("value_badges"):
        content_y = draw_value_badges(draw, scene.get("value_badges") or [], content_y, accent) + 8

    images = existing_image_paths(scene)
    if images:
        boxes = image_boxes_for_content(content_y, len(images))
        labels = scene.get("image_labels", [])
        image_mode = scene.get("image_mode") or "contain"
        animate_image = bool(scene.get("animate_image", profile.get("animate_middle", False)))
        motion_amount = float(scene.get("motion_amount", profile.get("motion_amount", 0.028))) if animate_image else 0.0
        motion_direction = scene.get("motion_direction") or profile.get("motion_direction") or "zoom_in"
        for idx, path in enumerate(images[:4]):
            paste_fit(
                canvas,
                path,
                boxes[idx],
                mode=image_mode,
                outline=accent,
                motion_progress=progress,
                motion_direction=motion_direction,
                motion_amount=motion_amount,
            )
            if idx < len(labels):
                x1, y1, _, _ = boxes[idx]
                rounded(draw, (x1 + 12, y1 + 12, x1 + 158, y1 + 46), 12, "#1D2525", accent, 1)
                draw.text((x1 + 24, y1 + 16), str(labels[idx]), font=font(20, True), fill="#F7F2DE")
        return

    metrics = scene.get("metrics") or profile.get("metrics") or []
    for idx, metric in enumerate(metrics[:4]):
        draw_metric_card(draw, 130 + idx * 215, max(520, content_y + 22), metric, metric.get("accent") or accent)

    bullets = scene.get("visual_lines") or []
    yy = max(670, content_y + 156 if metrics else content_y + 24)
    for line in bullets[:4]:
        if yy > 790:
            break
        rounded(draw, (150, yy, 930, yy + 45), 14, "#1F2929", accent, 1)
        draw_centered(draw, line, yy + 8, font(24, True), "#FFFFFF")
        yy += 58


def draw_bottom(canvas: Image.Image, scene: dict[str, Any]) -> None:
    draw = ImageDraw.Draw(canvas)
    accent = scene.get("accent") or "#167A6F"
    line_count = len(scene.get("bottom_lines", []) or [])
    dense = bool(scene.get("dense_bottom")) or line_count >= 4
    y1, y2 = (840, 1092) if dense else (876, 1072)
    rounded(draw, (76, y1, 1004, y2), 22, "#1F2929", accent, 3)
    draw.rectangle((430, y1 - 3, 650, y1 + 7), fill=accent)
    title_size = int(scene.get("bottom_title_font_size") or (34 if dense else 38))
    body_size = int(scene.get("bottom_font_size") or (25 if dense else 27))
    line_step = int(scene.get("bottom_line_step") or (31 if dense else 34))
    title = scene.get("bottom_title", "")
    draw_centered(draw, title, y1 + (24 if dense else 28), font(title_size, True), "#FFFFFF")
    yy = y1 + (76 if dense else 88)
    for line in scene.get("bottom_lines", []):
        body_f = font(body_size, bool(scene.get("bottom_bold_lines", False)))
        for wrapped in wrap_text(draw, line, body_f, 850):
            tw, _ = text_size(draw, wrapped, body_f)
            draw.text(((W - tw) / 2, yy), wrapped, font=body_f, fill="#DCE7E1")
            yy += line_step
    footer = scene.get("footer", "")
    if footer:
        foot_f = font(21, True)
        tw, _ = text_size(draw, footer, foot_f)
        rounded(draw, (int((W - tw) / 2 - 18), y2 - 38, int((W + tw) / 2 + 18), y2 - 11), 12, "#F6F3EA")
        draw.text(((W - tw) / 2, y2 - 38), footer, font=foot_f, fill=accent)


def render_frame(profile: dict[str, Any], scene: dict[str, Any], out: Path, *, progress: float = 0.0) -> None:
    canvas = make_bg(scene.get("accent") or profile.get("accent") or "#167A6F")
    draw = ImageDraw.Draw(canvas)
    draw_title(draw, profile, scene)
    draw_visual(canvas, profile, scene, progress=progress)
    draw_bottom(canvas, scene)
    canvas.convert("RGB").save(out, quality=95)


def render_animated_visual(
    profile: dict[str, Any],
    scenes: list[dict[str, Any]],
    durations: list[float],
    frames_dir: Path,
    tmp_dir: Path,
) -> Path:
    fps = int(profile.get("animation_fps", 30))
    clips: list[Path] = []
    for idx, (scene, duration) in enumerate(zip(scenes, durations), start=1):
        scene_dir = frames_dir / f"scene_{idx:02d}"
        scene_dir.mkdir(parents=True, exist_ok=True)
        frame_count = max(2, int(round(duration * fps)))
        for frame_idx in range(frame_count):
            progress = frame_idx / max(1, frame_count - 1)
            render_frame(profile, scene, scene_dir / f"frame_{frame_idx:04d}.png", progress=progress)
        clip = tmp_dir / f"scene_{idx:02d}.mp4"
        run([
            "ffmpeg",
            "-y",
            "-framerate",
            str(fps),
            "-i",
            str(scene_dir / "frame_%04d.png"),
            "-vf",
            "fps=30,format=yuv420p",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(clip),
        ])
        clips.append(clip)

    concat = tmp_dir / "scene_clips.txt"
    with concat.open("w", encoding="utf-8") as handle:
        for clip in clips:
            handle.write(f"file '{clip.resolve()}'\n")
    visual = tmp_dir / "visual.mp4"
    run([
        "ffmpeg",
        "-y",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        str(concat),
        "-c",
        "copy",
        "-movflags",
        "+faststart",
        str(visual),
    ])
    return visual


def ffprobe_duration(path: Path) -> float:
    proc = run([
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        str(path),
    ])
    return float(proc.stdout.strip())


def has_audio_stream(path: Path) -> bool:
    proc = run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "a",
            "-show_entries",
            "stream=index",
            "-of",
            "csv=p=0",
            str(path),
        ],
        check=False,
    )
    return proc.returncode == 0 and bool(proc.stdout.strip())


def packaged_assets_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "assets"


def packaged_bgm_candidates(profile: dict[str, Any]) -> list[Path]:
    assets_dir = packaged_assets_dir()
    if not assets_dir.is_dir():
        return []

    names: list[str] = []
    for value in (
        profile.get("bgm_asset"),
        profile.get("bgm_asset_filename"),
        profile.get("default_bgm_asset"),
    ):
        if value:
            names.append(str(value))

    candidates = [(assets_dir / name) for name in names]
    patterns = [
        "manten_diloty*.mp3",
        "*M5000035rV5M0Ci5Bo*.mp3",
        "requested_bgm_manten_diloty*.mp3",
    ]
    for pattern in patterns:
        candidates.extend(sorted(assets_dir.glob(pattern)))
    return candidates


def first_existing_bgm_path(profile: dict[str, Any]) -> Path | None:
    candidates: list[Any] = [
        os.environ.get("CAPSULE_BGM_PATH"),
        os.environ.get("CAPSULE_CINEMA_BGM_PATH"),
        profile.get("bgm_path"),
        profile.get("background_music_path"),
        profile.get("music_path"),
    ]
    music_selection = profile.get("music_selection")
    if isinstance(music_selection, dict):
        candidates.extend(
            [
                music_selection.get("bgm_path"),
                music_selection.get("music_path"),
                music_selection.get("background_music_path"),
            ]
        )

    candidates.extend(packaged_bgm_candidates(profile))
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(str(candidate)).expanduser()
        if path.is_file():
            return path.resolve()
    return None


def mix_background_music(video: Path, music: Path, out: Path, volume: float) -> None:
    if has_audio_stream(video):
        filter_complex = (
            "[0:a]aformat=sample_rates=48000:channel_layouts=stereo[base];"
            f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={volume}[bgm];"
            "[base][bgm]amix=inputs=2:duration=first:dropout_transition=0.2[aout]"
        )
    else:
        filter_complex = f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={volume}[aout]"

    run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(video),
            "-stream_loop",
            "-1",
            "-i",
            str(music),
            "-filter_complex",
            filter_complex,
            "-map",
            "0:v",
            "-map",
            "[aout]",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            "-movflags",
            "+faststart",
            str(out),
        ]
    )


def find_project_root() -> Path:
    env_root = os.environ.get("CAPSULE_CINEMA_ROOT") or os.environ.get("VIDEO_AGENT_ROOT")
    candidates: list[Path] = []
    if env_root:
        candidates.append(Path(env_root).expanduser())
    candidates.extend([Path.cwd(), Path(__file__).resolve()])
    for start in candidates:
        current = start if start.is_dir() else start.parent
        for parent in (current, *current.parents):
            if (parent / "scripts" / "env_loader.py").exists() and (parent / "lib").exists():
                return parent.resolve()
    raise SystemExit(
        "Cannot locate Capsule Cinema project root. Run from the repo root or set CAPSULE_CINEMA_ROOT."
    )


def synthesize_tts(root: Path, text: str, out: Path, speed: float) -> dict[str, Any]:
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(root / "lib"))
    from scripts.env_loader import load_video_agent_env

    load_video_agent_env(root / "scripts")
    from custom_tools.audio_generation.minimax_tts_tool import synthesize_with_minimax

    result = synthesize_with_minimax(
        text,
        str(out),
        voice_type="zh_male_jieshuoxiaoming_moon_bigtts",
        speed=speed,
    )
    if result.get("success"):
        result["duration"] = ffprobe_duration(out)
    return result


def write_concat(frames: list[Path], durations: list[float], out: Path) -> None:
    with out.open("w", encoding="utf-8") as handle:
        for frame, duration in zip(frames, durations):
            handle.write(f"file '{frame.resolve()}'\n")
            handle.write(f"duration {duration:.3f}\n")
        handle.write(f"file '{frames[-1].resolve()}'\n")
        handle.write("duration 0.033\n")
        handle.write(f"file '{frames[-1].resolve()}'\n")


def write_prompt_snapshots(profile: dict[str, Any], output_dir: Path, params_path: Path, topic: str) -> list[dict[str, Any]]:
    prompts_dir = output_dir / "prompts"
    render_dir = prompts_dir / "render"
    render_dir.mkdir(parents=True, exist_ok=True)

    profile_snapshot = render_dir / "repo_showcase_profile_v001.json"
    snapshot = {
        "type": "repo_showcase_profile",
        "topic": topic,
        "source_params_path": str(params_path),
        "profile": profile,
    }
    profile_snapshot.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    prompt_index = prompts_dir / "prompt_index.json"
    index = {
        "schema": "capsule_cinema.prompt_index.v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "entries": [
            {
                "id": "repo_showcase_profile_v001",
                "category": "render",
                "path": str(profile_snapshot.relative_to(output_dir)),
                "source_params_path": str(params_path),
            }
        ],
    }
    prompt_index.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return [
        {"path": str(prompt_index.resolve()), "category": "storyboard_prompt", "title": "Prompt index"},
        {"path": str(profile_snapshot.resolve()), "category": "storyboard_prompt", "title": "Repo showcase profile"},
    ]


def add_visible_text(lines: list[str], value: Any) -> None:
    if value is None:
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            add_visible_text(lines, item)
        return
    for line in str(value).splitlines():
        cleaned = line.strip()
        if cleaned:
            lines.append(cleaned)


def collect_visible_text(profile: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    seen: set[str] = set()

    for scene in profile.get("scenes") or []:
        add_visible_text(lines, scene.get("tag") or profile.get("tag") or "repo showcase")
        add_visible_text(lines, profile.get("top_title"))
        add_visible_text(lines, profile.get("top_subtitle"))
        add_visible_text(lines, scene.get("visual_title") or scene.get("bottom_title") or profile.get("project_name"))
        add_visible_text(lines, scene.get("hero_value_text"))
        for badge in scene.get("value_badges") or []:
            add_visible_text(lines, badge.get("value") or badge.get("text"))
            add_visible_text(lines, badge.get("label"))

        images = existing_image_paths(scene)
        if images:
            add_visible_text(lines, list(scene.get("image_labels", []))[: len(images[:4])])
        else:
            for metric in (scene.get("metrics") or profile.get("metrics") or [])[:4]:
                add_visible_text(lines, metric.get("value"))
                add_visible_text(lines, metric.get("label"))
            add_visible_text(lines, list(scene.get("visual_lines") or [])[:4])

        add_visible_text(lines, scene.get("bottom_title"))
        add_visible_text(lines, scene.get("bottom_lines") or [])
        add_visible_text(lines, scene.get("footer"))

    deduped: list[str] = []
    for line in lines:
        if line not in seen:
            deduped.append(line)
            seen.add(line)
    return deduped


def write_visible_text_and_lint(profile: dict[str, Any], output_dir: Path, root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    qa_dir = output_dir / "qa"
    visible_text_path = qa_dir / "visible_text_for_lint.txt"
    visible_text_path.write_text("\n".join(collect_visible_text(profile)) + "\n", encoding="utf-8")

    artifacts = [
        {"path": str(visible_text_path.resolve()), "category": "qa_visible_text", "title": "Visible text for lint"}
    ]
    lint_script = root / "scripts" / "visible_copy_lint.py"
    lint_report = qa_dir / "visible_copy_lint.json"
    if not lint_script.exists():
        status = {"requested": False, "success": False, "reason": f"lint script not found: {lint_script}"}
        lint_report.write_text(json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        artifacts.append({"path": str(lint_report.resolve()), "category": "qa_report", "title": "Visible copy lint report"})
        return artifacts, status

    proc = run([sys.executable, str(lint_script), str(visible_text_path), "--json"], check=False)
    report_text = proc.stdout.strip() or json.dumps(
        {"ok": proc.returncode == 0, "stderr": proc.stderr.strip()},
        ensure_ascii=False,
        indent=2,
    )
    lint_report.write_text(report_text + "\n", encoding="utf-8")
    artifacts.append({"path": str(lint_report.resolve()), "category": "qa_report", "title": "Visible copy lint report"})
    status = {"requested": True, "success": proc.returncode == 0, "report": str(lint_report.resolve())}
    if proc.returncode != 0:
        raise SystemExit(f"visible copy lint failed; see {lint_report}\n{proc.stdout}{proc.stderr}")
    return artifacts, status


def render_video(profile: dict[str, Any], output_dir: Path, root: Path, params_path: Path, topic: str) -> dict[str, Any]:
    release_dir = output_dir / "release"
    work_dir = output_dir / "work"
    frames_dir = work_dir / "frames"
    audio_dir = work_dir / "audio"
    qa_dir = output_dir / "qa"
    tmp_dir = work_dir / "tmp"
    for directory in (release_dir, frames_dir, audio_dir, qa_dir, tmp_dir):
        directory.mkdir(parents=True, exist_ok=True)

    scenes = profile.get("scenes") or []
    if not scenes:
        raise SystemExit("params profile must include scenes")

    visible_text_artifacts, visible_lint_status = write_visible_text_and_lint(profile, output_dir, root)
    animate_middle = bool(profile.get("animate_middle") or any(scene.get("animate_image") for scene in scenes))

    frames: list[Path] = []
    for idx, scene in enumerate(scenes, start=1):
        out = frames_dir / f"frame_{idx:02d}.png"
        render_frame(profile, scene, out, progress=0.5 if animate_middle else 0.0)
        frames.append(out)

    voiceover = profile.get("voiceover", "")
    if not voiceover and profile.get("voiceover_required", True):
        raise SystemExit("voiceover is required")

    tts_status: dict[str, Any] = {"requested": bool(voiceover), "success": False}
    duration = float(profile.get("target_duration", 60))
    if voiceover:
        tts_path = audio_dir / "voiceover.mp3"
        tts_status = synthesize_tts(root, voiceover, tts_path, float(profile.get("tts_speed", 1.24)))
        if not tts_status.get("success"):
            raise SystemExit(f"TTS failed: {tts_status.get('error') or tts_status}")
        duration = float(tts_status["duration"])

    weights = [max(1, len(str(scene.get("narration", scene.get("bottom_title", ""))))) for scene in scenes]
    raw = [duration * weight / sum(weights) for weight in weights]
    durations = [max(3.5, item) for item in raw]
    scale = duration / sum(durations)
    durations = [item * scale for item in durations]

    if animate_middle:
        visual = render_animated_visual(profile, scenes, durations, frames_dir, tmp_dir)
    else:
        concat = tmp_dir / "frames.txt"
        visual = tmp_dir / "visual.mp4"
        write_concat(frames, durations, concat)
        run([
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat),
            "-vf",
            "fps=30,format=yuv420p",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(visual),
        ])

    base_video = tmp_dir / "base_audio.mp4"
    final_video = release_dir / "video.mp4"
    if voiceover:
        run([
            "ffmpeg",
            "-y",
            "-i",
            str(visual),
            "-i",
            str(audio_dir / "voiceover.mp3"),
            "-map",
            "0:v",
            "-map",
            "1:a",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            "-movflags",
            "+faststart",
            str(base_video),
        ])
    else:
        run(["ffmpeg", "-y", "-i", str(visual), "-c:v", "copy", "-an", "-movflags", "+faststart", str(base_video)])

    bgm_status: dict[str, Any] = {
        "requested": bool(profile.get("add_background_music", True)),
        "success": False,
        "title": profile.get("bgm_title") or profile.get("default_bgm_label") or profile.get("default_bgm_title") or "",
    }
    bgm_path = first_existing_bgm_path(profile) if bgm_status["requested"] else None
    if bgm_path:
        bgm_volume = float(profile.get("bgm_volume", 0.85 if not voiceover else 0.16))
        mix_background_music(base_video, bgm_path, final_video, bgm_volume)
        bgm_status.update({"success": True, "path": str(bgm_path), "volume": bgm_volume})
    else:
        run(["ffmpeg", "-y", "-i", str(base_video), "-c", "copy", "-movflags", "+faststart", str(final_video)])
        if bgm_status["requested"]:
            bgm_status["reason"] = "No local licensed BGM path supplied via bgm_path/background_music_path/CAPSULE_BGM_PATH."

    copy_path = release_dir / "copy.txt"
    copy_path.write_text(profile.get("copy", profile.get("top_title", "")) + "\n", encoding="utf-8")
    prompt_artifacts = write_prompt_snapshots(profile, output_dir, params_path, topic)
    run_notes = {
        "ok": True,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "topic": topic,
        "tts_status": tts_status,
        "bgm_status": bgm_status,
        "visible_copy_lint": visible_lint_status,
        "frame_count": len(frames),
        "animate_middle": animate_middle,
        "duration": ffprobe_duration(final_video),
    }
    run_notes_path = qa_dir / "run_notes.json"
    run_notes_path.write_text(json.dumps(run_notes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    manifest = {
        "artifacts": [
            {"path": str(final_video.resolve()), "category": "final_video", "title": "Final video"},
            {"path": str(copy_path.resolve()), "category": "copywriting", "title": "Copywriting"},
            {"path": str(run_notes_path.resolve()), "category": "run_notes", "title": "Run notes"},
            *visible_text_artifacts,
            *prompt_artifacts,
        ]
    }
    (output_dir / "artifact_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return run_notes


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topic", default="")
    parser.add_argument("--params", required=True, help="Path to repo showcase profile JSON.")
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = find_project_root()
    params_path = Path(args.params).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    profile = json.loads(params_path.read_text(encoding="utf-8"))
    if args.topic and "topic" not in profile:
        profile["topic"] = args.topic
    render_video(profile, output_dir, root, params_path, args.topic or profile.get("topic", ""))


if __name__ == "__main__":
    main()
